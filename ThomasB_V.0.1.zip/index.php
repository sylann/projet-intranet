<?php
include('include/fonctions.php');
echo hautPage ();
echo afficheMenu ();
echo afficheFooter ();
echo basPage ();
?>
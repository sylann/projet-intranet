<?php

function hautPage () { /** Fonction qui génère le haut de la page HTML. */
	return '<!DOCTYPE html>
<html>
<head>
	<title>GREPSI</title>
	<meta charset="UTF-8">
	<meta name="description" content="GREPSI - EPSI Grenoble">
	<meta name="keywords" content="EPSI, Grenoble">
	<meta name="language" content="fr">
	<meta name="author" content="Thomas BERARD, Nicolas BOUYSSOUNOUSE, Adrien CECCALDI, Nathan DESCOMBES, Jérôme FABBIAN, Florian GOJON, Théo GUIBOUD-RIBAUD, Guillaume SAYEN, Valentin SOVIGNET, Romain VINCENT">
	<link rel="stylesheet" type="text/css" href="style/bootstrap.css">
	<link rel="stylesheet" type="text/css" href="style/grepsi.css">
</head>
<body>
	';
}

function basPage () { /** Fonction qui génère le bas de la page HTML. */
	return '</body>
</html>';
}

function afficheMenu () { /** Fonction qui affiche la navbar en tête de page. */
	return '<nav id="cssmenu">
	<ul>
	<li><a href="#">Accueil</a></li>
	<li><a href="#">page1</a></li>
	<li><a href="#">page2</a></li>
	<li><a href="#">page3</a></li>
	<li><a href="#">page4</a></li>
	<li><a href="#">page5</a></li>
	</ul>
	</nav>
';
}

function afficheFooter () { /** Fonction qui affiche le footer en bas de page. */
	return '<footer id="cssfooter">
	<ul>
	<li id="epsi-logo"><a href="http://www.epsi.fr" target="_blank"><img src="images/epsi-logo.png" width="100px"></a></li>
</footer>
';
}

?>
